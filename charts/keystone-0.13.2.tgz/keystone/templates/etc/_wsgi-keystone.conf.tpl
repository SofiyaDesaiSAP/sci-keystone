# Copyright 2017 The Openstack-Helm Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

Listen 0.0.0.0:5000

{{- /* mod_wsgi request/queue/script timestamps (microsecond epoch), exposed as
       Apache env vars by WSGIServerMetrics. Downstream: queue_wait = script_start
       - queue_start. Logged as strings so unset ("-") stays valid JSON. Only
       emitted when metrics (and thus WSGIServerMetrics On) are enabled. */ -}}
{{- $wsgiJson := "" -}}
{{- $wsgiPlain := "" -}}
{{- if .Values.api.metrics.enabled -}}
{{- $wsgiJson = ",\\\"wsgi_request_start\\\":\\\"%{mod_wsgi.request_start}e\\\",\\\"wsgi_queue_start\\\":\\\"%{mod_wsgi.queue_start}e\\\",\\\"wsgi_script_start\\\":\\\"%{mod_wsgi.script_start}e\\\"" -}}
{{- $wsgiPlain = " wsgi_request_start=%{mod_wsgi.request_start}e wsgi_queue_start=%{mod_wsgi.queue_start}e wsgi_script_start=%{mod_wsgi.script_start}e" -}}
{{- end -}}
{{- if .Values.use_json }}
ErrorLog /dev/stdout
ErrorLogFormat "%M"
LogFormat "{\"timestamp\":\"%{%Y-%m-%dT%H:%M:%S}t.%{msec_frac}t\",\"pid\":%{pid}P,\"levelname\":\"INFO\",\"name\":\"apache.access\",\"request_id\":\"%{X-Openstack-Request-ID}i\",\"client_ip\":\"%a\",\"method\":\"%m\",\"uri\":\"%U%q\",\"protocol\":\"%H\",\"status\":%>s,\"bytes_sent\":%B,\"duration_ms\":%{ms}T,\"referer\":\"%{Referer}i\",\"user_agent\":\"%{User-Agent}i\"{{ $wsgiJson }}}" json_combined
LogFormat "{\"timestamp\":\"%{%Y-%m-%dT%H:%M:%S}t.%{msec_frac}t\",\"pid\":%{pid}P,\"levelname\":\"INFO\",\"name\":\"apache.access\",\"request_id\":\"%{X-Openstack-Request-ID}i\",\"client_ip\":\"%{X-Forwarded-For}i\",\"method\":\"%m\",\"uri\":\"%U%q\",\"protocol\":\"%H\",\"status\":%>s,\"bytes_sent\":%B,\"duration_ms\":%{ms}T,\"referer\":\"%{Referer}i\",\"user_agent\":\"%{User-Agent}i\"{{ $wsgiJson }}}" json_proxy
SetEnvIf X-Forwarded-For "^.*\..*\..*\..*" forwarded
CustomLog /dev/stdout json_combined env=!forwarded
CustomLog /dev/stdout json_proxy env=forwarded
{{- else }}
ErrorLog /dev/stdout
LogFormat "%{%Y-%m-%d %T}t.%{msec_frac}t %{pid}P INFO apache \"%{X-Openstack-Request-ID}i\" %h %l %u \"%r\" %>s %b %{ms}T \"%{Referer}i\" \"%{User-Agent}i\"{{ $wsgiPlain }}" combined
LogFormat "%{%Y-%m-%d %T}t.%{msec_frac}t %{pid}P INFO apache \"%{X-Openstack-Request-ID}i\" %{X-Forwarded-For}i %l %u \"%r\" %>s %b %{ms}T \"%{Referer}i\" \"%{User-Agent}i\"{{ $wsgiPlain }}" proxy
SetEnvIf X-Forwarded-For "^.*\..*\..*\..*" forwarded
CustomLog /dev/stdout combined env=!forwarded
CustomLog /dev/stdout proxy env=forwarded
{{- end }}


{{- if .Values.federation.oidc.enabled }}
<Location "/v3/auth/OS-FEDERATION/websso/openid">
    AuthType "openid-connect"
    Require claim sub~.+
</Location>

<Location "/v3/auth/OS-FEDERATION/identity_providers/sap-ias/protocols/openid/websso">
    AuthType "openid-connect"
    Require claim sub~.+
</Location>

<Location "/v3/auth/OS-FEDERATION/identity_providers/sap-ias/protocols/openid/auth">
    AuthType "openid-connect"
    Require claim sub~.+
</Location>

# Location a non-browser apps can communicate with
<Location "/v3/OS-FEDERATION/identity_providers/sap-ias/protocols/openid/auth">
    # AuthType here is not "openid-connect" since apps going here do not support browser flow
    AuthType "auth-openidc"
    Require claim sub~.+
</Location>

{{- end }}

{{- if .Values.api.metrics.enabled }}
# Enable mod_wsgi request/process metrics so the per-process worker sampler
# (loaded via WSGIImportScript below) can read mod_wsgi.process_metrics().
WSGIServerMetrics On
{{- end }}

<VirtualHost *:5000>
    ServerName {{ .Values.services.public.host }}.{{ .Values.global.region }}.{{ .Values.global.tld }}
    WSGIDaemonProcess keystone-public processes=8 threads=1 user=keystone group=keystone display-name=%{GROUP}
    {{- if .Values.api.metrics.enabled }}
    # Load the worker-pool sampler into every keystone-public daemon process.
    # It reports each process's active_requests to statsd for Prometheus.
    WSGIImportScript /scripts/wsgi-sampler.py process-group=keystone-public application-group=%{GLOBAL}
    {{- end }}
    WSGIProcessGroup keystone-public
    WSGIScriptAlias / /var/www/cgi-bin/keystone/keystone-wsgi-public
    WSGIApplicationGroup %{GLOBAL}
    WSGIPassAuthorization On
    LimitRequestBody 114688
    # LimitRequestFieldSize is needed because of OIDC, 2*default
    LimitRequestFieldSize 16380
    <IfVersion >= 2.4>
      {{- if .Values.use_json }}
        ErrorLogFormat "%M"
      {{- else }}
        ErrorLogFormat "%{cu}t %M"
      {{- end }}
    </IfVersion>
    ErrorLog /dev/stdout
    {{- if .Values.use_json }}
        SetEnvIf X-Forwarded-For "^.*\..*\..*\..*" forwarded
        CustomLog /dev/stdout json_combined env=!forwarded
        CustomLog /dev/stdout json_proxy env=forwarded
    {{- else }}
        SetEnvIf X-Forwarded-For "^.*\..*\..*\..*" forwarded
        CustomLog /dev/stdout combined env=!forwarded
        CustomLog /dev/stdout proxy env=forwarded
    {{- end }}
    KeepAliveTimeout 61

    {{- if .Values.federation.saml.enabled }}
    # Shibboleth handler — matches the default /Shibboleth.sso and all
    # per-tenant handler URLs (/Shibboleth.sso/<tenant>/*).
    # Each tenant's ApplicationOverride has its own handlerURL so the ACS
    # endpoint is unique per tenant, ensuring correct applicationId routing.
    <LocationMatch "^/Shibboleth\.sso(/|$)">
        SetHandler shib
    </LocationMatch>

    # Per-tenant auth endpoints (one .conf per tenant, mounted from the
    # keystone-saml-federation-saml-tenants ConfigMap; ConfigMap content comes
    # from the federation repo's generated/<region>/federation-saml.d/).
    IncludeOptional /etc/apache2/conf-enabled/federation-saml.d/*.conf
    {{- end }}
</VirtualHost>

Alias /identity /var/www/cgi-bin/keystone/keystone-wsgi-public
<Location /identity>
    SetHandler wsgi-script
    Options +ExecCGI

    WSGIProcessGroup keystone-public
    WSGIApplicationGroup %{GLOBAL}
    WSGIPassAuthorization On
</Location>
